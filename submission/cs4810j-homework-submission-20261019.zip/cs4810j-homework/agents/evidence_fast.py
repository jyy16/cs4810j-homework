"""GUI agent that saves a compact notebook of evidence from visible pages.

The LLM performs the UI actions. Read-only DOM observations record values needed
for cross-page comparisons, so the agent does not have to revisit pages.
"""

import asyncio
import json
import re
from collections import Counter

from browser_use import Agent, BrowserSession, Tools
from browser_use.agent.views import ActionResult
from browser_use.llm.messages import UserMessage

from harness.context import Context, Verdict
from harness.tasks import Task


# Only inspect the current page. No task oracle, database, or bug script is read.
VISIBLE_PAGE = r"""() => {
  const visible = element => element && element.getClientRects().length > 0;
  const label = element => element?.innerText?.trim() || '';
  const entries = root => root ? [...root.querySelectorAll('a.entity-list-item')]
    .filter(visible).map(element => ({
      name: label(element.querySelector('.entity-list-item-name')) || label(element).split('\n')[0],
      type: element.getAttribute('data-entity-type') || '',
      href: element.getAttribute('href') || '',
      lines: label(element).split('\n').map(s => s.trim()).filter(Boolean)
    })) : null;
  const result = {
    url: location.pathname + location.search,
    title: label(document.querySelector('main h1')) || label(document.querySelector('h1')),
    recently_viewed: entries(document.querySelector('#recently-viewed .entity-list')),
    profile_pages: null,
    search: null,
    book: null,
    books_listing: null,
    form: null
  };
  const countArea = document.querySelector('#content-counts');
  if (visible(countArea)) {
    const pageCount = [...countArea.querySelectorAll('a')]
      .map(label).map(s => s.match(/^(\d+)\s+Pages?$/i)).find(Boolean);
    if (pageCount) result.profile_pages = Number(pageCount[1]);
  }
  const searchHeading = [...document.querySelectorAll('h1')]
    .find(element => label(element) === 'Search Results');
  if (visible(searchHeading)) {
    const card = searchHeading.closest('.card');
    const total = label(card).match(/(\d+)\s+total results found/i);
    result.search = {
      total_label: total ? Number(total[1]) : null,
      entries: entries(card?.querySelector('.book-contents .entity-list')),
      has_pagination: Boolean(card?.querySelector('.pagination, nav[aria-label*="pagination" i]'))
    };
  }
  const bookContents = document.querySelector('main .book-content .book-contents');
  if (visible(bookContents)) result.book = {
    title: label(document.querySelector('main h1')),
    entries: entries(bookContents)
  };
  if (location.pathname === '/books') {
    const main = document.querySelector('main');
    result.books_listing = main ? [...main.querySelectorAll('a[href*="/books/"]')]
      .filter(visible).map(element => ({
        href: element.getAttribute('href') || '',
        lines: label(element).split('\n').map(s => s.trim()).filter(Boolean)
      })).filter(entry => entry.lines.length >= 2) : null;
  }
  const name = document.querySelector('input[name="name"]');
  const editor = [...document.querySelectorAll('iframe')]
    .find(frame => /rich text/i.test(frame.title || '') && visible(frame));
  if (visible(name) && editor) result.form = {
    name: name.value,
    description: editor.contentDocument?.body?.innerText?.trim() || ''
  };
  return result;
}"""


EXCLUDED_TOOLS = ['search', 'navigate', 'search_page', 'find_elements', 'save_as_pdf', 'upload_file', 'evaluate']


def build_prompt(task: Task) -> str:
    steps = '\n'.join(
        f'{i}. ACTION: {step.action}\n   EXPECTED: {step.expectation}'
        for i, step in enumerate(task.steps, 1)
    )
    return f"""You are a QA tester running a GUI test case on BookStack.
The browser is already logged in. Use only the app's links, buttons, and forms;
do not type or navigate to a URL yourself.

Test case: {task.name}
{steps}

At every step, check the EXPECTED result on the visible page before continuing.
For form inputs, make sure the intended field received the text. Use the
fill_rich_text action for a visible rich text editor; it types through the UI
and checks the editor content.
If your own click or typing went to the wrong field, correct it through the UI
and verify both fields before continuing. An action error is not an app failure.
For a cross-page comparison, record the first page's exact count or ordered
list, including repeated names. On the next page, count actual visible entries,
not just a summary label. For search, note the chapters and pages grouped under
the named book, then compare them with that book's contents.

Once both sides of a comparison have been seen, decide from those observations.
Do not revisit a page just to recall a value you already recorded. If an
expectation still fails after a correctly performed UI action, stop without
working around the app.
Finish with done. State the observed evidence and end with exactly one line:
VERDICT: PASS if every expectation held, otherwise VERDICT: FAIL."""


class EvidenceNotebook:
    def __init__(self, browser: BrowserSession, ctx: Context):
        self.browser = browser
        self.ctx = ctx
        self.snapshots: list[dict] = []
        self.last_url: str | None = None

    async def capture(self, step: int | str) -> None:
        try:
            page = await self.browser.get_current_page()
            if page is None:
                return
            snapshot = json.loads(await page.evaluate(VISIBLE_PAGE))
            if self.last_url is not None and snapshot['url'] != self.last_url:
                # BookStack may update the visible DOM shortly after navigation.
                await asyncio.sleep(0.7)
                snapshot = json.loads(await page.evaluate(VISIBLE_PAGE))
            self.last_url = snapshot['url']
            snapshot['step'] = step
            # Consecutive identical pages add no evidence.
            if not self.snapshots or snapshot != {**self.snapshots[-1], 'step': step}:
                self.snapshots.append(snapshot)
        except Exception as exc:
            self.snapshots.append({'step': step, 'observation_error': str(exc)[:300]})

    def save(self) -> None:
        (self.ctx.out_dir / 'evidence.json').write_text(
            json.dumps(self.snapshots, indent=2, ensure_ascii=False), encoding='utf-8'
        )


def _entry_names(entries: list[dict]) -> list[str]:
    return [entry['name'] for entry in entries]


def _page_checks(task: Task, snapshots: list[dict]) -> list[str]:
    """Return only mismatches proved by visible pages; missing evidence is inconclusive."""
    expectations = ' '.join(step.expectation for step in task.steps).lower()
    mismatches = []

    if 'created content' in expectations and 'created pages' in expectations and 'consistent' in expectations:
        profiles = [s for s in snapshots if isinstance(s.get('profile_pages'), int)]
        searches = [s for s in snapshots if s.get('search') and s['search'].get('entries') is not None]
        if profiles and searches:
            profile_count = profiles[-1]['profile_pages']
            search = searches[-1]['search']
            rows = search['entries']
            if len(rows) > profile_count or (not search['has_pagination'] and len(rows) != profile_count):
                mismatches.append(
                    f'Created Content shows {profile_count} Pages, but the visible search list has '
                    f'{len(rows)} entries: {_entry_names(rows)}.'
                )

    if 'my recently viewed' in expectations and 'previous order' in expectations:
        dashboards = [s for s in snapshots if s.get('recently_viewed') is not None]
        match = re.search(r"['\"]([^'\"]+)['\"]\s+item appears at the top", expectations, re.I)
        if len(dashboards) >= 2 and match:
            target = match.group(1).casefold()
            before = dashboards[0]['recently_viewed']
            after = dashboards[-1]['recently_viewed']
            old_target = next((entry for entry in before if entry['name'].casefold() == target), None)
            unchanged = [entry['href'] for entry in before if entry is not old_target]
            remaining = [entry['href'] for entry in after[1:]]
            target_at_top = bool(after) and after[0]['name'].casefold() == target
            if not target_at_top or remaining != unchanged:
                mismatches.append(
                    f'My Recently Viewed before: {_entry_names(before)}; after: {_entry_names(after)}. '
                    f'The named book must be first and all other entries must keep their order.'
                )

    if 'chapters and pages' in expectations and 'previous search results' in expectations:
        target = next((m for step in task.steps
                       if (m := re.search(r"book title\s+['\"]([^'\"]+)['\"]", step.action, re.I))), None)
        searches = [(i, s) for i, s in enumerate(snapshots)
                    if s.get('search') and s['search'].get('entries') is not None]
        if target and searches:
            title = target.group(1)
            search_index, search = searches[0]
            book = next((s['book'] for s in snapshots[search_index + 1:]
                         if s.get('book') and s['book']['title'].casefold() == title.casefold()), None)
            # A single visible result page is incomplete when pagination exists.
            if book and book.get('entries') is not None and not search['search']['has_pagination']:
                from_search = Counter(
                    (e['type'], e['name']) for e in search['search']['entries']
                    if e['type'] in ('chapter', 'page') and len(e['lines']) > 1
                    and e['lines'][1].casefold() == title.casefold()
                )
                from_book = Counter(
                    (e['type'], e['name']) for e in book['entries']
                    if e['type'] in ('chapter', 'page')
                )
                if from_search and from_search != from_book:
                    mismatches.append(
                        f"Search lists {title}'s chapters/pages as {list(from_search.elements())}, "
                        f'but the visible book page lists {list(from_book.elements())}.'
                    )
    name_match = next((m for step in task.steps if
                       (m := re.search(r"Type ['\"]([^'\"]+)['\"] in (?:the )?Name field", step.action, re.I))), None)
    description_match = next((m for step in task.steps if
                              (m := re.search(r"Type ['\"]([^'\"]+)['\"] in (?:the )?Description", step.action, re.I))), None)
    if name_match and description_match:
        name, description = name_match.group(1), description_match.group(1)
        completed_forms = [(i, s) for i, s in enumerate(snapshots)
                           if s.get('form') == {'name': name, 'description': description}]
        if completed_forms:
            form_index = completed_forms[-1][0]
            listings = [s['books_listing'] for s in snapshots[form_index + 1:]
                        if s.get('books_listing') is not None]
            if listings:
                created = next((entry for entry in listings[-1]
                                if entry['lines'][0] == name), None)
                if created and description not in created['lines'][1:]:
                    mismatches.append(
                        f"Entered description {description!r} for {name!r}, but the "
                        f"visible Books listing shows {created['lines'][1]!r}."
                    )
    return mismatches


def make_tools() -> Tools:
    tools = Tools(exclude_actions=EXCLUDED_TOOLS)

    @tools.action('Fill the visible rich text editor through the mouse and keyboard, '
                  'then verify its displayed text. Use this for a rich text Description field.')
    async def fill_rich_text(text: str, browser_session: BrowserSession) -> ActionResult:
        page = await browser_session.must_get_current_page()
        geometry = json.loads(await page.evaluate('''() => {
          const frame = [...document.querySelectorAll('iframe')]
            .find(element => /rich text/i.test(element.title || '') && element.getClientRects().length);
          if (!frame) return null;
          const rect = frame.getBoundingClientRect();
          return {x: rect.left + rect.width / 2, y: rect.top + Math.min(40, rect.height / 2)};
        }'''))
        if not geometry:
            return ActionResult(error='No visible rich text editor found.')
        await (await page.mouse).click(geometry['x'], geometry['y'])
        focused = await page.evaluate('''() => {
          const frame = document.activeElement;
          return frame?.tagName === 'IFRAME' &&
            Boolean(frame.contentDocument?.activeElement?.isContentEditable);
        }''')
        if focused.lower() != 'true':
            return ActionResult(error='Rich text editor did not receive keyboard focus.')
        await page.press('Control+A')
        await page.press(text)
        actual = await page.evaluate('''() => {
          const frame = document.activeElement;
          return frame?.contentDocument?.body?.innerText?.trim() || '';
        }''')
        if actual != text:
            return ActionResult(error=f'Editor shows {actual!r}, expected {text!r}.')
        return ActionResult(extracted_content=f'Rich text editor visibly contains {actual!r}.')

    return tools


async def run_test(task: Task, ctx: Context) -> Verdict:
    browser = BrowserSession(cdp_url=ctx.cdp_url)
    notebook = EvidenceNotebook(browser, ctx)
    proven_mismatches: list[str] = []
    short_case = len(task.steps) <= 3

    async def should_stop() -> bool:
        # browser-use calls this before requesting the next LLM action. A proved
        # mismatch ends the run without spending tokens on repeated page visits.
        await notebook.capture('before action')
        if not proven_mismatches:
            proven_mismatches.extend(_page_checks(task, notebook.snapshots))
            if proven_mismatches:
                await ctx.trace_step('Visible-page comparison failed')
        return bool(proven_mismatches)

    async def on_step(state, output, step_number):
        await ctx.trace_step(f'Step {step_number}: {getattr(output, "next_goal", "") or "observe and act"}')
        await notebook.capture(step_number)

    agent = Agent(
        task=build_prompt(task),
        llm=ctx.llm(),
        browser_session=browser,
        tools=make_tools(),
        use_vision=False,  # browser-use disables vision for this DeepSeek model anyway
        use_judge=False,
        directly_open_url=False,
        max_failures=3,
        final_response_after_failure=False,
        # Browser-use requires at least six history items. Short cases stay
        # within that window; flash mode removes verbose planning fields.
        max_history_items=6 if short_case else 8,
        flash_mode=short_case,
        register_new_step_callback=on_step,
        register_should_stop_callback=should_stop,
        save_conversation_path=ctx.out_dir / 'conversation',
        generate_gif=str(ctx.out_dir / 'agent.gif'),
    )
    try:
        history = await agent.run(max_steps=max(9, len(task.steps) + 8))
    finally:
        await notebook.capture('final')
        notebook.save()
    history.save_to_file(ctx.out_dir / 'history.json')
    mismatches = _page_checks(task, notebook.snapshots)
    if mismatches:
        return Verdict(passed=False, reason='Visible-page comparison failed: ' + ' '.join(mismatches))
    if not history.is_done():
        raise RuntimeError(f'Agent stopped without finishing: {[e for e in history.errors() if e][-1:]}')
    final = history.final_result() or ''
    return Verdict(passed=await read_verdict(final, ctx) == 'PASS', reason=final)


async def read_verdict(report: str, ctx: Context) -> str:
    match = re.search(r'VERDICT\s*:\s*(PASS|FAIL)', report, re.IGNORECASE)
    if match:
        return match.group(1).upper()
    question = ('Here is a QA tester\'s report on a GUI test case. Did every expectation hold? '
                f'Answer with exactly one word, PASS or FAIL.\n\n{report}')
    answer = (await ctx.llm().ainvoke([UserMessage(content=question)])).completion.strip().upper()
    if answer.startswith(('PASS', 'FAIL')):
        return answer[:4]
    raise RuntimeError(f'No verdict in report: {report[:300]!r}')
