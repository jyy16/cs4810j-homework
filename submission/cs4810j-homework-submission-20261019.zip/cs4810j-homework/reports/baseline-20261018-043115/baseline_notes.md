# Baseline run notes

Run: `baseline-20261018-043115`  
Agent: `agents/baseline.py`  
Model: `deepseek-flash` via `https://api.arc-bench.com/v1`  
Scope: all eight `dev` scenario variants (four clean, four bug)

## Measured results

| Metric | Result |
| --- | ---: |
| Correct verdicts | 6 / 8 |
| Accuracy | 0.75 |
| Bug recall | 0.50 |
| False alarm rate | 0.00 |
| Errors | 0 |
| Average agent time | 56.0 seconds/test |
| Average tokens | 77,075/test |
| Total agent time | 448 seconds |
| Total tokens | 616,603 |

The test command exited with status 1 because two bug variants were judged `PASS` when the expected verdict was `FAIL`. All eight runs completed and have records in `results.json` and the self-contained `report.html`.

## Missed bugs observed in the browser evidence

- `count_recently_created_pages-bug`: The profile showed **6 Pages**. The search page said **6 total results found**, but its visible list contained **seven** page entries. The agent accepted the summary text without counting the entries. The trace's final frame and conversation step 4 show both values. Agent time: **27.4 s**; tokens: **42,663**.
- `recently_viewed_book-bug`: The initial dashboard list had 12 entries, including `Book2` at position 10 and two `Chapter 2` entries. After visiting `Book2`, the dashboard put it first but showed only 10 entries; both `Chapter 2` entries were gone. The agent recognized the move to the top but incorrectly claimed the other entries were retained. The trace's final frame and conversation steps 1 and 4 show the lists. Agent time: **24.9 s**; tokens: **42,349**.

The observations above come from the agent's browser trace and conversation, without relying on bug injection code. The trace ZIP files, `history.json`, `record.json`, and conversations remain in each case folder.
