# Agent 改进与迭代记录

改进文件：`agents/evidence_agent.py`（从 `agents/baseline.py` 复制后修改）。基线证据在 `reports/baseline-20261018-043115/`，是 `deepseek-flash` 的完整 8 项运行；准确率 6/8，平均 56.0 秒、77,075 token。本节的初步试跑均为筛选用例，完整对比见末尾及 `comparison_report.md`。

## 为什么这样改

| 可见页面和对话中的证据 | 基线问题 | 改进动作 |
| --- | --- | --- |
| 个人资料显示 **6 Pages**；“View All”搜索页写“6 total results found”，但实际有 **7 个可见页面条目**。 | 只信结果标题，`count_recently_created_pages[bug]` 错判 `PASS`。 | 同时保存资料页计数和搜索页逐条列表，以实际条目数核对。 |
| 首次首页“Recently Viewed”有 12 项；访问 Book2 后，Book2 到首位，但两个 `Chapter 2` 项消失，只剩 10 项。 | 只核对 Book2 到首位，`recently_viewed_book[bug]` 错判 `PASS`。 | 保存完整有序列表；移除原 Book2 后，逐项对比其他链接的相对顺序与数量，保留重名项。 |
| 搜索页把 Book2 的章节、页面列为 `Chapter 1`、`Chapter 2`、`Page 1`；图书页显示 `Page 3`。 | 基线在两页间往返，`search[bug]` 用了 18 次模型调用。 | 首次访问两页时记录可见条目的类型、名称及所属图书，比较后立即判定。 |

这些数值与名称只作为**本次观察证据**记录在这里。程序没有写入任何固定正确数量、固定列表、测试变体或 bug 脚本内容；判定值在每次运行时从当前浏览器页面读取，并依据 `Task.steps` 的可见动作和预期选择比较方式。

## 实现操作

1. 保留 baseline 的 browser-use UI 操作方式，提示模型逐步核对预期、记录跨页值，不为回忆已记录的信息反复导航。
2. 在浏览器步骤中只读提取当前页的资料计数、搜索列表、最近浏览顺序及图书内容，保存为每个案例的 `evidence.json`。页面地址变化后等待短暂渲染再采集。
3. 根据可见预期比较两页证据；仅在证据明确矛盾时把结论设为 `FAIL`。证据缺失时不猜测，让 agent 自己完成判定或由框架记录错误。
4. 使用 browser-use 的停止回调，在下一次模型请求前结束已证实失败的场景；把历史窗口限制为 8 项，并限制最大步骤数，减少重复调用。

## 初步验证（非完整评测）

| bug 案例 | 基线：结论 / 秒 / token / 调用 | 当前版本：结论 / 秒 / token / 调用 | 当前报告目录 |
| --- | --- | --- | --- |
| 最近创建页面数 | PASS / 27.4 / 42,663 / 4 | FAIL / 20.6 / 31,604 / 3 | `reports/evidence_agent-20261018-050050/` |
| 最近浏览图书 | PASS / 24.9 / 42,349 / 4 | FAIL / 23.3 / 30,911 / 3 | `reports/evidence_agent-20261018-050134/` |
| 搜索 | FAIL / 190.4 / 222,122 / 18 | FAIL / 20.3 / 30,568 / 3 | `reports/evidence_agent-20261018-050134/` |

验证过程：编译新文件；用只读浏览器操作核对三种 clean 页面均无矛盾、三种 bug 页面均检出可见差异；随后运行改进 agent 的针对性 pytest。较早的两项试跑在 `reports/evidence_agent-20261018-045645/`：当时尚未加入提前停止回调，创建页面数 bug 虽判对但用了 7 次模型调用、124.4 秒。这直接促成第 4 项改动。新增回调后单独复测降至 3 次调用、20.6 秒。

云环境复现命令：

```bash
UV_CACHE_DIR=/tmp/cs4810j-uv-cache uv run pytest --agent evidence_agent -k 'count_recently_created_pages and bug'
UV_CACHE_DIR=/tmp/cs4810j-uv-cache uv run pytest --agent evidence_agent -k 'bug and (recently_viewed_book or search)'
```

## 第四步：完整运行、失败与修正

先单独验证搜索正常版与缺陷版：`reports/evidence_agent-20261018-050842/`，2/2 正确。再验证建书两项：`reports/evidence_agent-20261018-050957/`，2/2 正确，但检查历史发现代理使用了浏览器脚本设置富文本内容；正式版应只通过界面输入。

首次完整运行 `reports/evidence_agent-20261018-051228/` 为 7/8 正确、平均 39.4 秒和 53,239 token。错误是建书正常版误报：代理把描述输入到书名字段，却把自身操作失误当成应用失败。于是先明确“验证字段、修正自己的误操作”，并禁用代理调用 `evaluate`。第二次完整运行 `reports/evidence_agent-20261018-052651/` 达到 8/8，平均 token 降到 67,586，但建书两项反复尝试编辑器焦点，平均耗时升至 66.2 秒。

针对这个实测瓶颈，加入通用 `fill_rich_text` 动作：从当前可见 iframe 取得位置，通过鼠标与键盘输入，确认编辑器焦点和实际文字；只读观察不用于写入页面。也从可见表单和图书列表记录描述，仅当已确认正确输入且列表显示不同内容时提前结束。建书两项筛选复测在 `reports/evidence_agent-20261018-073445/`，均判对，分别为 48.4 与 40.9 秒。

当时的最终完整运行 `reports/evidence_agent-20261018-073639/` 为 **8/8 正确、平均 27.8 秒、44,145 token、4.2 次调用**。基线对应 **6/8、56.0 秒、77,075 token、6.9 次调用**。该阶段的 `metrics.py` 输出后来另存于 `comparison_metrics_previous.txt`。一次建书缺陷版复测曾遭遇接口 `401 invalid_api_key` 中途错误，目录为 `reports/evidence_agent-20261018-051933/`；接口恢复后重新运行，不将这次中断纳入正式对比。

## 后续优化：短用例精简模式

为减少三步用例的规划输出，复制稳定版为 `agents/evidence_fast.py`。对三步用例启用 browser-use `flash_mode`，将历史窗口由 8 缩到库允许的最小值 6；这些用例通常只需 3–4 次模型调用，因此实测节省主要来自精简输出格式。七步建书用例仍用原设置。另在搜索与图书内容的自动完整性比较中遇到搜索分页时跳过单页判定，避免把不完整的一页当作全部结果。第一次把窗口设为 2 时，browser-use 启动前报告必须大于 5，未产生模型调用；修正为 6 后继续评测。

两个目标正常版筛选试跑 `reports/evidence_fast-20261018-081721/` 均正确：最近创建页面数为 23.2 秒、21,271 token；搜索为 22.7 秒、20,116 token。**正式完整 8 项** `reports/evidence_fast-20261018-081830/` 全部正确，平均 **24.2 秒、31,313 token、4.4 次调用**。相对前一完整改进版，平均耗时下降 13%，token 下降 29%，调用次数略升 3%；相对基线，正确率从 6/8 到 8/8，平均耗时下降 57%，token 下降 59%。正式 `comparison_metrics.txt` 与 `comparison_report.md` 已更新为基线对这次完整运行；旧版对比另存 `comparison_metrics_previous.txt`。
